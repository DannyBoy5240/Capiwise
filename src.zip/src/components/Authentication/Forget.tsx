import { FC } from "react";

const Home: FC = () => {
  return <h1>{"This is home screen"}</h1>;
};

export default Home;
